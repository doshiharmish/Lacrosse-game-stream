# Drill storage plugins

These files include drill plugins for connecting to:

- minio
- mssql
- mongodb

To use create a new plugin under drill plugin managemen